Liste de mots Moore r�alis�e � partir du dictionnaire Moore de Mr Norbert Nikiema.
Encore imparfait...
R�alis� par Etienne de Boissezon (edbz@free.fr)
avec l'appui du Sedelan (www.abcburkina.net)

Marche avec les version > 2.0.3 de Openoffice

Ajouter la ligne "mos BF mos_BF" dans votre dictionary.lst
Puis s�lectionnez la langue Moore dans openoffice
