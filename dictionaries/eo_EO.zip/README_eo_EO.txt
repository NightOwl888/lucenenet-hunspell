English:
========



Esperanto:
=======
Esperanta literumilo por OpenOffice.org

Priskribo

Ĉi tio estas esperanta literumilo por OpenOffice.org en la MySpell-formato. Ĝi estas kreita surbaze de la literumilo por ISpell fare de Sergio Pokrovskij. En la MySpell-formaton tradukis Dmitri Gabinski.
La arĥivo enhavas tri dosierojn:
eo_EO.dic — vortaro;
eo_EO.aff — afiksaro;
legumin.html — ĉi tiu dosiero (dankon al Bertilo Wennergren, kiu korektis kelkajn erarojn en ĝi).

Instalo kaj uzo

Atentu: kvankam la versio 1.1 de OOo havas esperanton en la listo de subtenataj lingvoj, aligi la literumilon kiel esperantan malsukcesas. Do aligu ĝin kiel nacilingvan. Agu sekvamaniere:
1. Elarĥivigu la dosierojn eo_EO.dic kaj eo_EO.aff kaj metu ilin en la subdosierujon ../share/dict/ooo/ de la dosierujo, kie troviĝas OOo.
2. Redaktu la dosieron dictionary.lst. Mi sukcesis aligi la literumilon kiel italan kaj kiel hispanan, aldoninte al dictionary.lst linion, respektive, "DICT it IT eo_EO" aŭ "DICT es ES eo_EO" (sen citiloj, kompreneble). Se vi bezonas tiujn lingvojn, provu alian, tamen mi ne scias, kiuj taŭgas. Mi provis ankaŭ la norvegan "Bokmal" (per linio "DICT no NO eo_EO"), sed tiaokaze la literumilo eraris.
3. Eliru el ĉiuj lanĉitaj kromaĵoj de OOo kaj — nepre — ankaŭ el la rapidstartigilo "Quickstarter". Relanĉu OOo-n kaj marku esperantan tekston kiel italan, hispanan aŭ alilingvan — laŭ via maniero de aligo.

Disvastigo

Ĉi tiu literumilo estas disvastigata laŭ la GNU-a ĝenerala publika permesilo (Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA). This spellchecker is available on the terms of GNU General Public License (Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA).
