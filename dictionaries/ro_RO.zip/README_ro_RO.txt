The Romanian (ro_RO) MySpell dictionary is derived by Manfred Pohler
(Manfred.Pohler@gmx.net) from the Ispell dictionary created by Mihai Budiu
(http://www.cs.cmu.edu/~mihaib).
The Ispell dictionary is licensed under GPL, so the MySpell dictionary is
also GPL.
Read the GPL here - http://www.gnu.org/licenses/gpl.txt


ro,RO,ro_RO,Romanian (Romania),ro_RO.zip

DICT ro RO ro_RO

---------------------------------------------------------------------------

Dic�ionarul rom�nesc (ro_RO) pentru MySpell este derivat de Manfred Pohler 
(Manfred.Pohler@gmx.net) din dic�ionarul pentru Ispell creat de Mihai Budiu 
(http://www.cs.cmu.edu/~mihaib).
Dic�ionarul pentru Ispell este licen�iat sub GPL, deci dic�ionarul pentru 
MySpell este de asemenea GPL.
Citi�i textul GPL aici - http://www.gnu.org/licenses/gpl.txt
