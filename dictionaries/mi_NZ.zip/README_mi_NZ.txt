Te Papakupu Maori o Aotearoa
(C) 2008 Kiharoa (Konrad) Dear
Version 0.4.20080630
http://papakupu.maori.nz/



Place Names
http://www.tetaurawhiri.govt.nz/

Place names from Te Taura Whiri i te Reo Maori were produced as a sample of
of the Maori names for the benefit of the public.



Iwi Names from 2006 Census
(C) 2008 Statistics New Zealand
http://www.stats.govt.nz/

List of iwi who consented and have profiles available as at 17 March 2008
from the Statistics New Zealand.



Whakamaori Technology terms
(C) 2008 Te Taka Keegan
http://www.cs.waikato.ac.nz/~tetaka/

A sample list of terms used in the te reo Maori translation of Microsoft
Office, Microsoft Windows XP and Moodle.



Kedri Translator
(C) 2008 Dr. Mark Laws and Dr. Michael Watts
http://translator.kedri.info/

The English-Maori Word Translator provides a bilingual interface to
translating between English to Maori and vice-versa.  It also has the ability
to present to a user, the correct pronounciation of a Maori word.

Full details on the translator and the ongoing research work into Maori
language analysis is available from the Kedri website.

Many thanks to Dr. Mark Laws for allowing the use of the word-list to be
included into the Maori Papakupu project.



Te Ngutu Kura
(C) 2008 Karaitiana N Taiuru
http://www.maorispellchecker.net.nz/

Te Ngutu Kura spell-checker is a freely available Maori dictionary for
Microsoft Office and includes a character map to input macrons.

The word-list is taken from the corpus of words used by Te Ngutu Kuru under
terms and conditions of the GPLv3.

Many thanks to Karaitiana for re-licensing the word-list so that it could be
incorporated into Te Papakupu Maori.



Orthographic Conventions
http://www.tetaurawhiri.govt.nz/

A sample of publicly available words from Te Taura Whiri i te reo Maori.



Nga Ture Kupu
(C) 2008 Kiharoa (Konrad) Dear
http://papakupu.maori.nz/
