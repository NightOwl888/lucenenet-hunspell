name   :  th_TH 0.3 version of the thai dictionary
date   :  2005.09.20
License:  LGPL
Copyright 2005 by NECTEC, Thailand

This dictionary, Thai wordlist are compound from 
 - LEXiTRON dictionary (http://lexitron.nectec.or.th/) Online English-Thai, Thai-English Dictionary by NECTEC.
 - Unknown Thai word from NECTEC researched.

It use for Pspell, Aspell and Myspell.

Thanks to everybody for their wonderful work.

Sila Chunwijitra <hin@opentle.org>
Maintainer

:
