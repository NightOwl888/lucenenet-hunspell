This Slovenian dictionary was created by (in alphabetical order):
   Amebis, d.o.o.
   Toma"z Erjavec
   Ale"s Ko"sir
   Primo"z Peterlin

The Slovenian dictionary is covered by the GNU/LGPL and GNU/GPL License and  
supports Slovenian language (sl_SI)

The affix file was adapted by:
Robert Ludvik, <r@aufbix.org>

Project was supported in part by Ministry of Information Society (MID, Republic of Slovenia)
and Linux User Group of Slovenia (Lugos).

Bug report: <ales.kosir@pingo.org>


=======================================================================================
http://external.openoffice.org/ form data:

Product Name: Slovenian spellcheck dictionary
Product Version: 1.0
Vendor or Owner Name: Amebis, d.o.o., Toma"z Erjavec, Ale"s Ko"sir, Primo"z Peterlin
Vendor or Owner Contact: ales.kosir@pingo.org
OpenOffice.org Contact: bobe@openoffice.org
Date of First Use / date of License: NA/October 2006
URL for Product Information: http://nl.ijs.si/GNUsl/
URL for License: http://www.gnu.org/copyleft/lgpl.html
Purpose: Slovenian spellcheck dictionary
Type of Encryption: none
Binary or Source Code: Source
=======================================================================================