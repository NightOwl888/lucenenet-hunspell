Myspell dictionary
------------------

Language: Norwegian Bokmal (nb NO)
Origin:   Generated from the spell-norwegian source v2.0.7
License:  GNU General Public license
Author:   The spell-norwegian project, <URL:https://alioth.debian.org/projects/spell-norwegian/>

DICT nb NO nb_NO
