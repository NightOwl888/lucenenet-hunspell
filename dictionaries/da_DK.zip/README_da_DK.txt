
                  Stavekontrolden ver. 1.0 - 02-09-2007

Stavekontrolden er et projekt under Foreningen for frit tilg�ngelige
sprogv�rkt�jer. Foreningen blev stiftet i februar 2007 af Esben Aaberg, Jeppe
Bundsgaard og Finn Gruwier Larsen som en udl�ber af f�llesskabet omkring den
danske udgave af kontorpakken OpenOffice.org. Baggrunden var en f�lles
opfattelse af, at den nuv�rende stavekontrolordbog i den danske OpenOffice.org-
pakke er et svagt punkt, og at et v�sentligt l�ft i kvaliteten er n�dvendigt. 

Grundlaget for Stavekontroldens ordliste er data, som er stillet til r�dighed
for projektet af Det Danske Sprog- og Litteraturselskab (www.dsl.dk). Den
f�rdige ordliste stilles til r�dighed under open source-licensen LGPL, hvilket
g�r det muligt at inkludere den i open source-programmer som f. eks.
OpenOffice.org.

L�s mere om projektet:

www.stavekontrolden.dk