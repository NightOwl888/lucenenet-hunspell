
                             ¡¡¡ VERSIÓN BETA !!!

                       ¡¡¡ NO UTILIZAR EN PRODUCCIÓN !!!


  *** Diccionario para corrección ortográfica en español de OpenOffice.org ***

                               Versión 0.1beta


SUMARIO

1. AUTOR
2. LICENCIA
3. INSTALACIÓN
4. AGRADECIMIENTOS


1. AUTOR

   Este diccionario ha sido desarrollado por Santiago Bosio. Para contactar al
autor, por favor envíe sus mensajes mediante correo electrónico a:

	sbosio <en> fullzero <punto> com <punto> ar
        (reemplace <en> por @ y <punto> por . al enviar su mensaje)

   El diccionario es un desarrollo completamente nuevo, y NO ESTÁ BASADO en el
trabajo de Jesús Carretero y Santiago Rodríguez, ni en la versión adaptada al
formato de MySpell por Richard Holt.


2. LICENCIA

   Este diccionario para corrección ortográfica, integrado por el fichero
de afijos (es_NEW.aff) y la lista de palabras (es_NEW.dic) se distribuye bajo
licencia GNU LGPL (Lesser General Public License). Puede obtener una copia de
la licencia original (en inglés) en la siguiente dirección:

	http://www.gnu.org/licenses/lgpl.txt


3. INSTALACIÓN

   ¡¡¡ VERSIÓN BETA !!! Sólo para pruebas.

   Si desea efectuar pruebas y colaborar con el desarrollo de este
diccionario, realice una instalación manual:

   - Copie el fichero de afijos y la lista de palabras a la carpeta de
     instalación de diccionarios.
   - Edite el fichero 'dictionary.lst' para agregar el nuevo diccionario.
     Se sugiere instalar el diccionario con un código de localización distinto
     al que utiliza habitualmente, para no reemplazar el diccionario actual.
   - Configure las opciones de lingüística del programa a través del menú de
     herramientas.
   - Cierre todas las ventanas de OpenOffice.org y el inicio rápido.
   - Inicie nuevamente OpenOffice.org. Ahora todos los documentos nuevos serán
     revisados con el nuevo diccionario.
   - Tome nota de todas las correcciones, agregados, dudas y sugerencias y
     envíelas al autor.

   En caso de necesitar ayuda para cualquiera de estos pasos, envíe un mensaje
al autor del diccionario, o a las listas de discusión del proyecto
OpenOffice.org en español (http://es.openoffice.org/).


4. AGRADECIMIENTOS

   Hay varias personas que han colaborado con aportes o sugerencias a la
creación de este diccionario. Se agradece especialmente a:

   - Richard Holt.
   - Marcelo Garrone.
   - Kevin Hendricks.
   - Juan Rey Saura.
   - y a todos los que realicen pruebas para mejorar este diccionario.

